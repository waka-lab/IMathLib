﻿	function slideshow_init() {
		// スライドの枚数の取得
		var el_n = document.getElementById("slideshow").childElementCount;
		var delay = 6;			//スライド1枚あたりの表示時間

		// スライドの枚数だけ動的スライドを生成
		$("#slideshow li > span").css({
			"-webkit-animation":"image_animation " + (el_n * delay) + "s linear infinite 0s"
			, "-moz-animation":"image_animation " + (el_n * delay) + "s linear infinite 0s"
			, "-o-animation":"image_animation " + (el_n * delay) + "s linear infinite 0s"
			, "-ms-animation":"image_animation " + (el_n * delay) + "s linear infinite 0s"
			, "animation":"image_animation " + (el_n * delay) + "s linear infinite 0s"
		});
		$("#slideshow li > div").css({
			"-webkit-animation":"html_animation " + (el_n * delay) + "s linear infinite 0s"
			, "-moz-animation":"html_animation " + (el_n * delay) + "s linear infinite 0s"
			, "-o-animation":"html_animation " + (el_n * delay) + "s linear infinite 0s"
			, "-ms-animation":"html_animation " + (el_n * delay) + "s linear infinite 0s"
			, "animation":"html_animation " + (el_n * delay) + "s linear infinite 0s"
		});
		for (var i = 1; i <= el_n; ++i) {
			// 背景URLの取得
			var img_url = $("#slideshow li:nth-child(" + i + ") span").data("bgimg");

			$("#slideshow li:nth-child(" + i +") span").css({
				"background-image":"url(" + img_url + ")"
				, "-webkit-animation-delay": (i - 1) * delay +"s"
				, "-moz-animation-delay": (i - 1) * delay +"s"
				, "-o-animation-delay": (i - 1) * delay +"s"
				, "-ms-animation-delay": (i - 1) * delay +"s"
				, "animation-delay": (i - 1) * delay +"s"
			});
			$("#slideshow li:nth-child(" + i +") div").css({
				"-webkit-animation-delay": (i - 1) * delay +"s"
				, "-moz-animation-delay": (i - 1) * delay +"s"
				, "-o-animation-delay": (i - 1) * delay +"s"
				, "-ms-animation-delay": (i - 1) * delay +"s"
				, "animation-delay": (i - 1) * delay +"s"
			});
		}
	};
