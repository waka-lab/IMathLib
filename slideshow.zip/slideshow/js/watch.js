﻿	// 各月の日数の取得
	function date_of_month(year_v, month_v) {
		switch(month_v) {
			case 2:
				// 閏年の判定
				return ((year_v % 4 == 0) && (year_v % 100 != 0)) ? 29 : 28;
			case 4:
			case 6:
			case 9:
			case 11:
				return 30;
			default:
				return 31;
		}
	}

	// 時間の初期化
	var now = new Date();
	var year = now.getFullYear();
	var month = now.getMonth() + 1;
	var date = now.getDate();
	var hour = now.getHours();
	var minute = now.getMinutes();
	var second = now.getSeconds();
	// 各時間のキューブの更新フラグ
	var minute_update = second == 59;
	var hour_update = minute_update && (minute == 59);
	var date_update = hour_update && (hour == 23);
	var month_update = date_update && (date == date_of_month(year, month));
	var year_update = month_update && (month == 12);

	// 時間の更新
	function time_update() {
		now = new Date();
		hour = now.getHours();
		minute  = now.getMinutes();
		second  = now.getSeconds();
		minute_update = second == 59;
		hour_update = minute_update && (minute == 59);
		date_update = hour_update && (hour == 23);
		month_update = date_update && (date == date_of_month(year, month));
		year_update = month_update && (month == 12);
	}

	$(function(){
		// 数値(1桁)の0埋め
		function filled0(n) {
			return (n >= 10) ? String(n) : ('0' + n);
		}
		var t_second = $("#second");
		var t_minute = $("#minute");
		var t_hour = $("#hour");
		var t_date = $("#date");
		var t_month = $("#month");
		var t_year = $("#year");

		// 各種初期化
		if (minute_update) t_minute.addClass("animation");
		if (hour_update) t_hour.addClass("animation");
		if (date_update) t_date.addClass("animation");
		if (month_update) t_month.addClass("animation");
		if (year_update) t_year.addClass("animation");
		t_second.find(".front").text(filled0(second));
		t_second.find(".bottom").text(filled0((second + 1) % 60));
		t_minute.find(".front").text(filled0(minute));
		t_minute.find(".bottom").text(filled0((minute + 1) % 60));
		t_hour.find(".front").text(filled0(hour));
		t_hour.find(".bottom").text(filled0((hour + 1) % 24));
		t_date.find(".front").text(filled0(date));
		t_date.find(".bottom").text(filled0((date + 1) % (date_of_month(year, month) + 1)));
		t_month.find(".front").text(filled0(month));
		t_month.find(".bottom").text((month + 1) % 13);
		t_year.find(".front").text(year);
		t_year.find(".bottom").text(year + 1);

		t_second.on("animationiteration webkitAnimationIteration", function() {
			time_update();
			// 各種更新の設定
			if (minute_update) t_minute.addClass("animation");
			if (hour_update) t_hour.addClass("animation");
			if (date_update) t_date.addClass("animation");
			if (month_update) t_month.addClass("animation");
			if (year_update) t_year.addClass("animation");
			// bottomには次の状態をもってくる
			t_second.find(".front").text(filled0(second));
			t_second.find(".bottom").text(filled0((second + 1) % 60));
			t_minute.find(".front").text(filled0(minute));
			t_minute.find(".bottom").text(filled0((minute + 1) % 60));
			t_hour.find(".front").text(filled0(hour));
			t_hour.find(".bottom").text(filled0((hour + 1) % 24));
			t_date.find(".front").text(filled0(date));
			t_date.find(".bottom").text(filled0((date + 1) % (date_of_month(year, month) + 1)));
			t_month.find(".front").text(filled0(month));
			t_month.find(".bottom").text(filled0((month + 1) % 13));
			t_year.find(".front").text(year);
			t_year.find(".bottom").text(year + 1);
		});
		t_minute.on("animationiteration webkitAnimationIteration", function() {
			t_minute.removeClass("animation");
		});
		t_hour.on("animationiteration webkitAnimationIteration", function() {
			t_hour.removeClass("animation");
		});
		t_date.on("animationiteration webkitAnimationIteration", function() {
			t_date.removeClass("animation");
		});
		t_month.on("animationiteration webkitAnimationIteration", function() {
			t_month.removeClass("animation");
		});
		t_year.on("animationiteration webkitAnimationIteration", function() {
			t_year.removeClass("animation");
		});
	})
