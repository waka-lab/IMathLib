﻿import os
import shutil

# Question : 本来ならオブジェクトで実装したいところであるが，するほど価値ある？
# Anser : ないと思う(あまりにも環境依存が過ぎる)


# スライドデータのためのインデックス
slide_index = [
	# スライドHTML, スライド背景画像, [表示時間(s), フェードイン時間(s), フェードアウト時間(s)]
	# フェードインフェードアウト時間は他スライドと重複する
	["html/1.html", "images/1.jpg", [2, 0.5, 0.7]]
	#, ["html/2.html", "images/2.jpg", [6, 0.5, 0.7]]
	#, ["html/3.html", "images/3.jpg", [6, 0.5, 0.7]]
	#, ["html/4.html", "images/4.jpg", [6, 0.5, 0.7]]
	#, ["html/5.html", "images/5.jpg", [6, 0.5, 0.7]]
	#, ["html/6.html", "images/6.jpg", [6, 0.5, 0.7]]
	# <>で括られたものはリテラル
	, ["<notice>", "images/white.jpg", [2, 0.5, 0.7]]
	, ["<student>", "images/white.jpg", [2, 0.5, 0.7]]
	, ["<lecture>", "images/white.jpg", [6, 0.5, 0.7]]
]

# リテラルに対するスライドのスタイルの定義
notice_show_num = 2
student_show_num = 4
student_style = [
	["学籍番号", "align=\"center\""]
	, ["氏名", "align=\"left\""]
	, ["呼出日", "align=\"center\""]
	, ["呼出元", "align=\"left\""]
]
lecture_show_num = 4
lecture_style = [
	["日付", "align=\"center\""]
	, ["分類", "align=\"center\""]
	, ["時限", "align=\"center\""]
	, ["授業名", "align=\"left\""]
	, ["講師名", "align=\"left\""]
]


# このファイルの存在するディレクトリへのパス
dir_path = os.path.dirname(os.path.abspath(__file__)) + "/"


# リテラルに対応するスライドの枚数のカウントとスライド全体のHTML(ページ数のカウントやcssの生成で用いる)
literal_slide_num = [
	["<notice>", 0, [], "_red"]
	, ["<student>", 0, [], "_blue"]
	, ["<lecture>", 0, [], "_green"]
]

# データベースからお知らせに関するHTMLを生成
def make_notice():
	# データベースが存在しなければ実行しない
	if not os.path.exists(dir_path + "db/kosen_info/notice.csv"):
		return
	with open(dir_path + "db/kosen_info/notice.csv", "r", encoding = "utf-8-sig") as f:
		line = f.readline()
		cnt = 0			# 1スライドあたりに表示する対象をカウントするためのカウンタ
		while line:
			# 新しいスライドに遷移したかの判定
			if cnt == 0:
				literal_slide_num[0][2].append("<div class=\"literal_slide_contents" + literal_slide_num[0][3] + "\"><table>")
				literal_slide_num[0][1] += 1
			# 解析処理(一番最後の行はEOFのため解析する必要はない)
			data_list = line.split(",")
			literal_slide_num[0][2][-1] += "<tr><th><div>" + data_list[0] + "</div></th></tr>"
			literal_slide_num[0][2][-1] += "<tr><td align=\"left\"><div>" + data_list[1] + "</div></td></tr>"
			cnt += 1
			# スライドの終了
			if cnt == notice_show_num:
				literal_slide_num[0][2][-1] += "</table></div>"
				cnt = 0
			# 更新
			line = f.readline()

	# tableが閉じられていないなら閉じる
	if cnt != notice_show_num:
		literal_slide_num[0][2][-1] += "</table></div>"
	# ページ番号を含めたHTMLの生成
	for i in range(len(literal_slide_num[0][2])):
		literal_slide_num[0][2][i] = (
			"<div class=\"literal_slide_main" + literal_slide_num[0][3] + "\">"
			+ "<div class=\"title_bg1" + literal_slide_num[0][3] + "\"><div class=\"title_bg2" + literal_slide_num[0][3] + "\"><div class=\"title\"><div>"
			+ "お知らせ" + "</div></div><div class=\"page_num\"><div>[" + str(i + 1) + "/" + str(literal_slide_num[0][1])
			+ "]</div></div><div class=\"clr\"></div></div></div>"
			+ literal_slide_num[0][2][i] + "</div>"
		)


# データベースから学生呼び出しに関するHTMLを生成
def make_student():
	# データベースが存在しなければ実行しない
	if not os.path.exists(dir_path + "db/kosen_info/student.csv"):
		return
	with open(dir_path + "db/kosen_info/student.csv", "r", encoding = "utf-8-sig") as f:
		line = f.readline()
		cnt = 0			# 1スライドあたりに表示する対象をカウントするためのカウンタ
		while line:
			# 新しいスライドに遷移したかの判定
			if cnt == 0:
				literal_slide_num[1][2].append("<div class=\"literal_slide_contents" + literal_slide_num[1][3] + "\"><table>")
				# リスト名
				literal_slide_num[1][2][-1] += ("<tr>"
					+ "<th><div>" + student_style[0][0] + "</div></th>"
					+ "<th><div>" + student_style[1][0] + "</div></th>"
					+ "<th><div>" + student_style[2][0] + "</div></th>"
					+ "<th><div>" + student_style[3][0] + "</div></th>"
					+ "</tr>")
				literal_slide_num[1][1] += 1
			# 解析処理(一番最後の行はEOFのため解析する必要はない)
			data_list = line.split(",")
			data_list[3] += "：" + data_list[4]
			# 1人の学生に対する呼び出し項目数
			item_num = (len(data_list) - 2) // 3
			for i in range(1, item_num):
				data_list[2] += "<br>" + data_list[2 + 3 * 1]
				data_list[3] += "<br>" + data_list[3 + 3 * 1] + "：" + data_list[4 + 3 * 1]
			literal_slide_num[1][2][-1] += ("<tr>"
				+ "<td "+ student_style[0][1] +"><div>" + data_list[0] + "</div></td>"
				+ "<td "+ student_style[1][1] +"><div>" + data_list[1] + "</div></td>"
				+ "<td "+ student_style[2][1] +"><div>" + data_list[2] + "</div></td>"
				+ "<td "+ student_style[3][1] +"><div>" + data_list[3] + "</div></td>"
				+ "</tr>")
			cnt += 1
			# スライドの終了
			if cnt == student_show_num:
				literal_slide_num[1][2][-1] += "</table></div>"
				cnt = 0
			# 更新
			line = f.readline()

	# tableが閉じられていないなら閉じる
	if cnt != student_show_num:
		literal_slide_num[1][2][-1] += "</table></div>"
	# ページ番号を含めたHTMLの生成
	for i in range(len(literal_slide_num[1][2])):
		literal_slide_num[1][2][i] = (
			"<div class=\"literal_slide_main" + literal_slide_num[1][3] + "\">"
			+ "<div class=\"title_bg1" + literal_slide_num[1][3] + "\"><div class=\"title_bg2" + literal_slide_num[1][3] + "\"><div class=\"title\"><div>"
			+ "学生呼び出し" + "</div></div><div class=\"page_num\"><div>[" + str(i + 1) + "/" + str(literal_slide_num[1][1])
			+ "]</div></div><div class=\"clr\"></div></div></div>"
			+ literal_slide_num[1][2][i] + "</div>"
		)


# データベースから講義に関するHTMLを生成
def make_lecture():
	# データベースが存在しなければ実行しない
	if not os.path.exists(dir_path + "db/kosen_info/lecture.csv"):
		return
	with open(dir_path + "db/kosen_info/lecture.csv", "r", encoding = "utf-8-sig") as f:
		line = f.readline()
		cnt = 0			# 1スライドあたりに表示する対象をカウントするためのカウンタ
		while line:
			# 新しいスライドに遷移したかの判定
			if cnt == 0:
				literal_slide_num[2][2].append("<div class=\"literal_slide_contents" + literal_slide_num[2][3] + "\"><table>")
				# リスト名
				literal_slide_num[2][2][-1] += ("<tr>"
					+ "<th><div>" + lecture_style[0][0] + "</div></th>"
					+ "<th><div>" + lecture_style[1][0] + "</div></th>"
					+ "<th><div>" + lecture_style[2][0] + "</div></th>"
					+ "<th><div>" + lecture_style[3][0] + "</div></th>"
					+ "<th><div>" + lecture_style[4][0] + "</div></th>"
					+ "</tr>")
				literal_slide_num[2][1] += 1
			# 解析処理(一番最後の行はEOFのため解析する必要はない)
			data_list = line.split(",")
			literal_slide_num[2][2][-1] += ("<tr>"
				+ "<td "+ lecture_style[0][1] +"><div>" + data_list[0] + "</div></td>"
				+ "<td "+ lecture_style[1][1] +"><div>" + data_list[1] + "</div></td>"
				+ "<td "+ lecture_style[2][1] +"><div>" + data_list[2] + "</div></td>"
				+ "<td "+ lecture_style[3][1] +"><div>" + data_list[3] + "</div></td>"
				+ "<td "+ lecture_style[4][1] +"><div>" + data_list[4] + "</div></td>"
				+ "</tr>")
			cnt += 1
			# スライドの終了
			if cnt == lecture_show_num:
				literal_slide_num[2][2][-1] += "</table></div>"
				cnt = 0
			# 更新
			line = f.readline()

	# tableが閉じられていないなら閉じる
	if cnt != lecture_show_num:
		literal_slide_num[2][2][-1] += "</table></div>"
	# ページ番号を含めたHTMLの生成
	for i in range(len(literal_slide_num[2][2])):
		literal_slide_num[2][2][i] = (
			"<div class=\"literal_slide_main" + literal_slide_num[2][3] + "\">"
			+ "<div class=\"title_bg1" + literal_slide_num[2][3] + "\"><div class=\"title_bg2" + literal_slide_num[2][3] + "\"><div class=\"title\"><div>"
			+ "休講・補講案内" + "</div></div><div class=\"page_num\"><div>[" + str(i + 1) + "/" + str(literal_slide_num[2][1])
			+ "]</div></div><div class=\"clr\"></div></div></div>"
			+ literal_slide_num[2][2][i] + "</div>"
		)


if __name__ == "__main__":
	
	main_text = ""
	insert_text = ""
	insert_text2 = ""
	sum_time = 0				# スライドショーの1ループあたりの時間
	# テンプレートHTMLファイルをmain_textへ読み込み
	with open(dir_path + "template/index.html", "r", encoding = "utf-8-sig") as f:
		main_text = f.read()

	for item in slide_index:
		if "<notice>" in item[0]:
			make_notice()
			for item2 in literal_slide_num[0][2]:
				insert_text += "<li><span></span><div>" + item2 + "</div></li>"
				sum_time += item[2][0]
		elif "<student>" in item[0]:
			make_student()
			for item2 in literal_slide_num[1][2]:
				insert_text += "<li><span></span><div>" + item2 + "</div></li>"
				sum_time += item[2][0]
		elif "<lecture>" in item[0]:
			make_lecture()
			for item2 in literal_slide_num[2][2]:
				insert_text += "<li><span></span><div>" + item2 + "</div></li>"
				sum_time += item[2][0]
		else:
			insert_text += "<li><span></span><div>"
			# テンプレートHTMLファイルをmain_textへ読み込み
			with open(dir_path + item[0], "r", encoding = "utf-8-sig") as f:
				insert_text += f.read()
			insert_text += "</div></li>"
			sum_time += item[2][0]

	# インクルードファイルの置換
	main_text = main_text.replace("![insert_slide]", insert_text)
	with open(dir_path + "index.html", "w", encoding = "utf-8-sig") as f:
		f.write(main_text)


	# ここからCSSの生成

	slide_cnt = 0				# スライド合計枚数のカウント
	sum_time2 = 0
	insert_text = ""
	insert_text3 = ""
	for item in slide_index:
		if "<notice>" in item[0]:
			# 共通部分のテキストを生成
			delay_percent1 = item[2][1] / sum_time * 100
			delay_percent2 = item[2][2] / sum_time * 100
			show_percent = item[2][0] / sum_time * 100
			insert_text2 = (
				"0% { opacity : 0; }"															# フェードイン開始
				+ str(delay_percent1) + "% { opacity : 1; }"										# フェードイン終了
				+ str(delay_percent1 + show_percent) + "% { opacity : 1; }"						# フェードアウト開始
				+ str(delay_percent1 + delay_percent2 + show_percent) + "% { opacity : 0; }"	# フェードアウト終了
				+ "100% { opacity : 0; }"
			)
			for item2 in literal_slide_num[0][2]:
				slide_cnt += 1
				insert_text += (
					"#slideshow li:nth-child(" + str(slide_cnt) + ") span {"
					+ "background-image : url(../" + item[1] + ");"
					+ "-webkit-animation : image_animation" + str(slide_cnt) + " " + str(sum_time) + "s linear infinite 0s;"
					+ "animation : image_animation" + str(slide_cnt) + " "  + str(sum_time) + "s linear infinite 0s;"
					+ "-webkit-animation-delay : " + str(sum_time2) + "s;"
					+ "animation-delay : "  + str(sum_time2) + "s;"
					+ "}"
				)
				insert_text += (
					"#slideshow li:nth-child(" + str(slide_cnt) + ") div {"
					+ "-webkit-animation : html_animation" + str(slide_cnt) + " " + str(sum_time) + "s linear infinite 0s;"
					+ "animation : html_animation" + str(slide_cnt) + " "  + str(sum_time) + "s linear infinite 0s;"
					+ "-webkit-animation-delay : " + str(sum_time2) + "s;"
					+ "animation-delay : "  + str(sum_time2) + "s;"
					+ "}"
				)
				insert_text += (
					"@keyframes image_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
				)
				insert_text += (
					"@-webkit-keyframes image_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
				)
				insert_text += (
					"@keyframes html_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
				)
				insert_text += (
					"@-webkit-keyframes html_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
				)
				sum_time2 += item[2][0]
		elif "<student>" in item[0]:
			# 共通部分のテキストを生成
			delay_percent1 = item[2][1] / sum_time * 100
			delay_percent2 = item[2][2] / sum_time * 100
			show_percent = item[2][0] / sum_time * 100
			insert_text2 = (
				"0% { opacity : 0; }"															# フェードイン開始
				+ str(delay_percent1) + "% { opacity : 1; }"										# フェードイン終了
				+ str(delay_percent1 + show_percent) + "% { opacity : 1; }"						# フェードアウト開始
				+ str(delay_percent1 + delay_percent2 + show_percent) + "% { opacity : 0; }"	# フェードアウト終了
				+ "100% { opacity : 0; }"
			)
			for item2 in literal_slide_num[1][2]:
				slide_cnt += 1
				insert_text += (
					"#slideshow li:nth-child(" + str(slide_cnt) + ") span {"
					+ "background-image : url(../" + item[1] + ");"
					+ "-webkit-animation : image_animation" + str(slide_cnt) + " " + str(sum_time) + "s linear infinite 0s;"
					+ "animation : image_animation" + str(slide_cnt) + " "  + str(sum_time) + "s linear infinite 0s;"
					+ "-webkit-animation-delay : " + str(sum_time2) + "s;"
					+ "animation-delay : "  + str(sum_time2) + "s;"
					+ "}"
				)
				insert_text += (
					"#slideshow li:nth-child(" + str(slide_cnt) + ") div {"
					+ "-webkit-animation : html_animation" + str(slide_cnt) + " " + str(sum_time) + "s linear infinite 0s;"
					+ "animation : html_animation" + str(slide_cnt) + " "  + str(sum_time) + "s linear infinite 0s;"
					+ "-webkit-animation-delay : " + str(sum_time2) + "s;"
					+ "animation-delay : "  + str(sum_time2) + "s;"
					+ "}"
				)
				insert_text += (
					"@keyframes image_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
				)
				insert_text += (
					"@-webkit-keyframes image_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
				)
				insert_text += (
					"@keyframes html_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
				)
				insert_text += (
					"@-webkit-keyframes html_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
				)
				sum_time2 += item[2][0]
		elif "<lecture>" in item[0]:
			# 共通部分のテキストを生成
			delay_percent1 = item[2][1] / sum_time * 100
			delay_percent2 = item[2][2] / sum_time * 100
			show_percent = item[2][0] / sum_time * 100
			insert_text2 = (
				"0% { opacity : 0; }"															# フェードイン開始
				+ str(delay_percent1) + "% { opacity : 1; }"										# フェードイン終了
				+ str(delay_percent1 + show_percent) + "% { opacity : 1; }"						# フェードアウト開始
				+ str(delay_percent1 + delay_percent2 + show_percent) + "% { opacity : 0; }"	# フェードアウト終了
				+ "100% { opacity : 0; }"
			)
			for item2 in literal_slide_num[2][2]:
				slide_cnt += 1
				insert_text += (
					"#slideshow li:nth-child(" + str(slide_cnt) + ") span {"
					+ "background-image : url(../" + item[1] + ");"
					+ "-webkit-animation : image_animation" + str(slide_cnt) + " " + str(sum_time) + "s linear infinite 0s;"
					+ "animation : image_animation" + str(slide_cnt) + " "  + str(sum_time) + "s linear infinite 0s;"
					+ "-webkit-animation-delay : " + str(sum_time2) + "s;"
					+ "animation-delay : "  + str(sum_time2) + "s;"
					+ "}"
				)
				insert_text += (
					"#slideshow li:nth-child(" + str(slide_cnt) + ") div {"
					+ "-webkit-animation : html_animation" + str(slide_cnt) + " " + str(sum_time) + "s linear infinite 0s;"
					+ "animation : html_animation" + str(slide_cnt) + " "  + str(sum_time) + "s linear infinite 0s;"
					+ "-webkit-animation-delay : " + str(sum_time2) + "s;"
					+ "animation-delay : "  + str(sum_time2) + "s;"
					+ "}"
				)
				insert_text += (
					"@keyframes image_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
				)
				insert_text += (
					"@-webkit-keyframes image_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
				)
				insert_text += (
					"@keyframes html_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
				)
				insert_text += (
					"@-webkit-keyframes html_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
				)
				sum_time2 += item[2][0]
		else:
			# 共通部分のテキストを生成
			delay_percent1 = item[2][1] / sum_time * 100
			delay_percent2 = item[2][2] / sum_time * 100
			show_percent = item[2][0] / sum_time * 100
			insert_text2 = (
				"0% { opacity : 0; }"															# フェードイン開始
				+ str(delay_percent1) + "% { opacity : 1; }"									# フェードイン終了
				+ str(delay_percent1 + show_percent) + "% { opacity : 1; }"						# フェードアウト開始
				+ str(delay_percent1 + delay_percent2 + show_percent) + "% { opacity : 0; }"	# フェードアウト終了
				+ "100% { opacity : 0; }"
			)
			slide_cnt += 1
			insert_text += (
				"#slideshow li:nth-child(" + str(slide_cnt) + ") span {"
				+ "background-image : url(../" + item[1] + ");"
				+ "-webkit-animation : image_animation" + str(slide_cnt) + " " + str(sum_time) + "s linear infinite 0s;"
				+ "animation : image_animation" + str(slide_cnt) + " "  + str(sum_time) + "s linear infinite 0s;"
				+ "-webkit-animation-delay : " + str(sum_time2) + "s;"
				+ "animation-delay : "  + str(sum_time2) + "s;"
				+ "}"
			)
			insert_text += (
				"#slideshow li:nth-child(" + str(slide_cnt) + ") div {"
				+ "-webkit-animation : html_animation" + str(slide_cnt) + " " + str(sum_time) + "s linear infinite 0s;"
				+ "animation : html_animation" + str(slide_cnt) + " "  + str(sum_time) + "s linear infinite 0s;"
				+ "-webkit-animation-delay : " + str(sum_time2) + "s;"
				+ "animation-delay : "  + str(sum_time2) + "s;"
				+ "}"
			)
			insert_text += (
				"@keyframes image_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
			)
			insert_text += (
				"@-webkit-keyframes image_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
			)
			insert_text += (
				"@keyframes html_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
			)
			insert_text += (
				"@-webkit-keyframes html_animation" + str(slide_cnt) + " {"+ insert_text2 + "}"
			)
			sum_time2 += item[2][0]

	# テンプレートCSSファイルをmain_textへ読み込み
	with open(dir_path + "template/slideshow.css", "r", encoding = "utf-8-sig") as f:
		main_text = f.read()
	main_text = main_text.replace("![slide_animation]", insert_text)

	with open(dir_path + "css/slideshow.css", "w", encoding = "utf-8-sig") as f:
		f.write(main_text)