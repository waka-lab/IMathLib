﻿import os
import shutil
import csv
import re
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin


# データベースディレクトリへのパス
db_path = os.path.dirname(os.path.abspath(__file__)) + "/db/kosen_info"
# ログインのためのURL
login_url = "http://keitai.kisarazu.ac.jp/selecti/login.asp"
# パスワード(シラバスに書いてあるやつ)
password = 312019
# 文字コード
char_code = "shift_jis"


# お知らせの走査
def find_notice(res):
    soup = BeautifulSoup(res.content, "html.parser")
    for a in soup.find_all("a"):
        if "メニューへ戻る" in a.string:
            break
        else:
            data_list = [a.string]
            res = session.get(urljoin(login_url, a.get("href")))
            res.raise_for_status()
            # hrタグ内に本題がある
            contents = re.findall(r"<hr>(.+)<hr>", res.content.decode(char_code).replace("\r\n", "").replace("<BR>", ""))[0]
            # CENTERタグはa.stringの文字であるため除去
            contents = re.sub(r"<CENTER>(.+)</CENTER>", "", contents)
            # 場所?情報
            place = re.findall(r"＜(.+)＞", contents)
            data_list.append(place[0] if (place) else "")
            # メインテキスト
            data_list.append(re.sub(r"＜(.+)＞", "", contents))
            # お知らせ情報の出力
            with open(db_path + "/notice.csv", "a", newline = "") as f:
                writer = csv.writer(f)
                writer.writerow(data_list)


# 講義案内の走査
def find_lecture(res):
    soup = BeautifulSoup(res.content, "html.parser")
    for a in soup.find_all("a"):
        if "本日の講義" in a.string:
            res = session.get(urljoin(login_url, a.get("href")))
            res.raise_for_status()
            soup2 = BeautifulSoup(res.content, "html.parser")
            data_list = []
            # 講義内容がない場合は終了
            if "講義案内はありません" in soup2.text:
                continue
            # centerから日付を取得
            for center in soup2.find_all("center"):
                if ("月" in center.string) and ("日" in center.string):
                    data_list.append(center.string)
            data_list.append(re.findall(r"(.+)●", soup2.text)[0].strip())
            data_list += re.findall(r"●(.+)", soup2.text)[0].strip().split(" ")
            # 呼び出し情報の出力
            with open(db_path + "/lecture_today.csv", "a", newline = "") as f:
                writer = csv.writer(f)
                writer.writerow(data_list)
        elif "メニューへ戻る" in a.string:
            break
            # 明日から2週間先
        else:
            # リンクがある場合は講義内容がないことがない(基本的に「本日の講義のコピペ」)
            res = session.get(urljoin(login_url, a.get("href")))
            res.raise_for_status()
            soup2 = BeautifulSoup(res.content, "html.parser")
            data_list = []
            # centerから日付を取得
            for center in soup2.find_all("center"):
                if ("月" in center.string) and ("日" in center.string):
                    data_list.append(center.string)
            data_list.append(re.findall(r"(.+)●", soup2.text)[0].strip())
            data_list += re.findall(r"●(.+)", soup2.text)[0].strip().split(" ")
            # 呼び出し情報の出力
            with open(db_path + "/lecture.csv", "a", newline = "") as f:
                writer = csv.writer(f)
                writer.writerow(data_list)


# 学生呼び出しの走査
def find_student(res):
    soup = BeautifulSoup(res.content, "html.parser")
    for a in soup.find_all("a"):
        # 次の10件が存在するなら走査
        if "次の10件" in a.string:
            res = session.get(urljoin(login_url, a.get("href")))
            res.raise_for_status()
            find_student(res)
        elif "前の10件" in a.string:
            break
        elif "メニューへ戻る" in a.string:
            break
        else:
            # 学籍番号と名前と内容
            data_list = a.string.split("：")
            # 日付と場所とメッセージの取得(●で始まる1行)
            res = session.get(urljoin(login_url, a.get("href")))
            res.raise_for_status()
            # パースの都合上<BR>を改行コードに変換
            soup2 = BeautifulSoup(res.content.decode(char_code).replace("<BR>", "\n"), "html.parser")
            find_list = re.findall(r"●(.+)", soup2.text)
            for item in find_list:
                # 向こうのスクリプトのミスかは不明だが，余計に空白をもっている場合がある
                data_list += item.strip().split(" ")
            # 呼び出し情報の出力(newlineで改行しないようにする)
            with open(db_path + "/student.csv", "a", newline = "") as f:
                writer = csv.writer(f)
                writer.writerow(data_list)



if __name__ == "__main__":

    # データベースの初期化
    if os.path.exists(db_path):
        shutil.rmtree(db_path)
    os.makedirs(db_path, exist_ok = True)

    # ログインするための情報
    login_info = {
        "PASSWORD" : password,
        "CMD" : "ログイン",
        "CHALLENGE" : "8996c3"
    }

    # ログイン処理
    session = requests.session()
    res = session.post(login_url, data = login_info)
    res.raise_for_status()      # エラーならここで例外を発生させる

    # res.contentはshift_jisによる文字化け対策(metaのcharsetに準拠)
    soup = BeautifulSoup(res.content, "html.parser")
    # 1.お知らせ～0.戻るまでを走査
    for a in soup.find_all("a"):
        res = session.get(urljoin(login_url, a.get("href")))        # 相対パスだから絶対パスに変換  
        res.raise_for_status()
        
        if "お知らせ" in a.string:
            find_notice(res)
        elif "講義案内" in a.string:
            find_lecture(res)
        elif "学生呼出" in a.string:
            find_student(res)
        elif "戻る" in a.string:
            break

